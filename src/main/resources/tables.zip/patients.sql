USE [OMSQLDB]
GO

/****** Object:  Table [dbo].[Patients]    Script Date: 11/23/2022 9:07:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Patients](
	[patient_id] [int] NOT NULL,
	[ID] [int] NULL,
	[First_Name] [nvarchar](40) NULL,
	[Last_Name] [nvarchar](40) NULL,
	[DOB] [datetime] NULL,
	[HL7ChargeSlip] [nvarchar](50) NULL,
	[HL7Facility] [nvarchar](50) NULL,
	[HL7ExternalID2] [nvarchar](50) NULL,
	[HL7PatientGroup] [nvarchar](50) NULL
) ON [PRIMARY]

GO

